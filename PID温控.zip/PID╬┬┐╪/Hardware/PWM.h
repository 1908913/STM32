#ifndef	_PWM_H_
#define	_PWM_H_

void PWM_Init(void);
void PWM_SetCompare3(uint16_t speed);
void PWM_SetCompare4(uint16_t speed);

#endif
