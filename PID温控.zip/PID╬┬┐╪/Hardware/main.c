#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Motor.h"
#include "Cooling.h"
#include "Key.h"
#include "DS18B20.h"
#include "PID.h"
#include "PID2.h"
#include "Timer.h"
#include "pwm.h"

uint8_t TEMP;						//���浽С��һλ��ʵ��ʵʱ�¶�
uint8_t SETTEMP;					//���浽С��һλ��ʵ�������¶�
uint8_t flag100ms;
uint8_t flag500ms;
uint8_t KeyNum;	
uint8_t	Hot_flag=0;
uint8_t	Cool_flag=0;


int	main(void)
{
	int8_t	Speed;
	int8_t	Speed2;
	uint16_t	Temp;
	//uint8_t Temp_Num;
	//uint8_t Key1;
	//uint8_t Key2;
	SETTEMP=25;
	
	Motor_Init();
	Cooling_Init();
	Key_Init();
	OLED_Init();
	DS18B20_UserConfig();
	PID_Init();
	PID2_Init();
	TIM3_Int_Init(10-1,7200);
	PWM_Init();
	
	OLED_ShowString(1, 1, "Speed");
	OLED_ShowString(1, 7,"Temp");
	OLED_ShowString(1, 13,"Mode");
	OLED_ShowString(3, 1,"SetTp");
	OLED_ShowString(3, 7,"Person");
	
	while(1)
	{
		
		KeyNum=Key_GetNum();
		if(KeyNum==2)
		{
			SETTEMP+=5;
			if(SETTEMP>45)
			SETTEMP=25;
			Hot_flag=1;
		}
		if(KeyNum==1)
		{
			SETTEMP-=1;
			if(SETTEMP<15)
			SETTEMP=25;
			Cool_flag=1;
		}
		
		Temp=DS18B20_Read_Temp();
		
		if(flag100ms==1)										//ÿ100ms����һ��ʵʱ�¶�
		{
			OLED_ShowString(4, 8, "Yes");
			flag100ms=0;		
			flag500ms++;
			if(flag500ms==5)
			{
				//OLED_ShowString(2, 14,"H");
				flag500ms=0;
				TEMP=Temp/10;
				OLED_ShowTemp(2,7,Temp,4);		//500ms����һ���¶�
				//OLED_ShowSignedNum(2,6,TEMP,4);
				OLED_ShowSignedNum(4,1,SETTEMP,3);
				
				if(SETTEMP<25)
				{
					//Cool_flag=1;
					Speed2=PID2_realize();
					Cooling_SetSpeed(Speed2);
					OLED_ShowString(2, 13, "Cool");
					OLED_ShowNum(2,1,Speed2,4);
					Motor_SetSpeed(0);
				}
				
				if(SETTEMP>=25&&SETTEMP<=30)
				{
					Cooling_SetSpeed(0);
					Motor_SetSpeed(0);
					OLED_ShowString(2, 13, "Wait");
					OLED_ShowString(2, 1, "Wait");
				}
				
				if(SETTEMP>30)
				{
					//Hot_flag=1;
					Speed=PID_realize();
				  Motor_SetSpeed(Speed);
					Cooling_SetSpeed(0);
					OLED_ShowString(2, 13, "Warm");
					OLED_ShowNum(2,1,Speed,4);
				}
			
			}
		}
		
		if(flag100ms==0)
		{
			flag100ms=0;		
			flag500ms++;
			if(flag500ms==5)
			{
				//OLED_ShowString(2, 14,"H");
				flag500ms=0;
				OLED_ShowTemp(2,7,Temp,4);		//500ms����һ���¶�
			}
			OLED_ShowString(2, 1, "Stop");
			OLED_ShowString(2, 13, "Stop");
			OLED_ShowString(4, 1, "Stop");
			OLED_ShowString(4, 8, "Not");
			//Cooling_SetSpeed(0);
			//Motor_SetSpeed(0);
		}
		
	}
}
