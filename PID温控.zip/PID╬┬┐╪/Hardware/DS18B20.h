#ifndef	_DS18B20_H
#define	_DS18B20_H

void	DS18B20_UserConfig(void);
void	DS18B20_Output_Input(uint8_t cmd);
uint8_t	DS18B20_Startup(void);
void	DS18B20_Write_Byte(uint8_t	data);
uint8_t	DS18B20_Read_Byte(void);
short	DS18B20_Read_Temp(void);

#endif
